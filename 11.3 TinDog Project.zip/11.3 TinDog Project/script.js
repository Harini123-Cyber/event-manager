import express from "express";
import session from "express-session";
import pg from "pg";
import bcrypt from "bcrypt";
import path from "path";

const app = express();
const port = 3000;



const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "tindog",
  password: "harini",
  port: 5432,
});

db.connect()
  .then(() => console.log("PostgreSQL Connected"))
  .catch(err => {
    console.error("DB Error:", err);
    process.exit(1);
  });



app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.set("view engine", "ejs");
app.set("views", path.join(process.cwd(), "views"));

app.use(
  session({
    secret: "my-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } 
  })
);


app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});




app.get("/", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  res.render("home");
});


app.get("/login", (req, res) => {
  res.render("login");
});


app.get("/register", (req, res) => {
  res.render("register");
});

app.get("/logout", (req, res) => {
    req.session.destroy(err => {
        if(err) {
            console.log(err);
        }
        res.redirect("/login");
    });
});


app.get("/event", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  
res.render("event");
});



app.post("/register", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.send("Email and password required");
  }

  try {
    const exists = await db.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );

    if (exists.rows.length > 0) {
      return res.send("User already exists");
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await db.query(
      "INSERT INTO users (email, password) VALUES ($1, $2) RETURNING *",
      [email, hashedPassword]
    );

    req.session.user = result.rows[0];
    res.redirect("/");
  } catch (err) {
    console.error(err);
    res.send("Registration failed");
  }
});

// Login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await db.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );

    if (result.rows.length === 0) {
      return res.send("User not found");
    }

    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password);

    if (!valid) {
      return res.send("Wrong password");
    }

    req.session.user = user;
    res.redirect("/");
  } catch (err) {
    console.error(err);
    res.send("Login failed");
  }
});



// Logout
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

/* ================= SERVER ================= */

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
