document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");

  loginForm.addEventListener("submit", (e) => {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (email === "" || password === "") {
      e.preventDefault(); // stop form submit
      alert("Please enter email and password");
      return;
    }

    // form submits normally to POST /login
  });
});
